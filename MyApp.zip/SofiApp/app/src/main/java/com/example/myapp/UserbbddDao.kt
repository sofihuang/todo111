package com.example.myapp

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface UserbbddDao {
    //suspend: para trabajar con corutinas,
    //que son una característica de Kotlin
    //para facilitar la programación asíncrona y concurrente
    @Query("SELECT * FROM user")
    suspend fun getAll(): List<Userbbdd>

    @Query("SELECT * FROM user WHERE gender LIKE:genero")
    suspend fun findByGender(genero: String): List<Userbbdd>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(books: List<Userbbdd>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(book: Userbbdd)

    @Update
    suspend fun updateUser(book: Userbbdd)

    @Delete
    suspend fun deleteUser(book: Userbbdd)
}