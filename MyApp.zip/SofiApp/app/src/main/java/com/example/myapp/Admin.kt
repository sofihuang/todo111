package com.example.myapp

import android.accounts.Account
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import com.example.myapp.databinding.ActivityAdminBinding
import com.example.myapp.databinding.ActivityFirstBinding

class Admin : AppCompatActivity() {
    private lateinit var binding: ActivityAdminBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Establece la Toolbar como la ActionBar de la actividad
        val toolbar = binding.toolbar
        setSupportActionBar(toolbar)

        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        setupBottomNavigationView()
    }

    // Inflar el menú
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

  //si elecciona share
  override fun onOptionsItemSelected(item: MenuItem): Boolean {
      when (item.itemId) {
          R.id.action_share -> {

              // debe ser el enlace de la aplicación en la Play Store, sustituyo otro
              val urlToShare = "https://tu-url-aqui.com"
              val sendIntent = Intent()
              sendIntent.action = Intent.ACTION_SEND
              sendIntent.putExtra(Intent.EXTRA_TEXT, urlToShare)
              sendIntent.type = "text/plain"
              startActivity(sendIntent)
              return true
          }
          else -> return super.onOptionsItemSelected(item)
      }
  }

    //nav menu
    private fun setupBottomNavigationView() {
        val bottomNavigationView = binding.menu1

        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.home -> {
                    // Navegar a MainActivity
                    val intent = Intent(this@Admin, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.history -> {
                    //en momento no hace nada
                    true
                }
                R.id.account -> {
                    //en momento no hace nada
                    true
                }
                else -> false
            }
        }
    }


}