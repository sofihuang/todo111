package com.example.myapp

import com.example.myapp.PhotoResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface PhotoService {
    @GET("api/")
    fun getRandomPhoto(@Query("gender") gender: String): Call<PhotoResponse>
}