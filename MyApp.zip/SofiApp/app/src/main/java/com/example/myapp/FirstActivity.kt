package com.example.myapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.View
import com.example.myapp.databinding.ActivityFirstBinding


class FirstActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFirstBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityFirstBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.userSig.visibility = View.INVISIBLE
        binding.passSig.visibility = View.INVISIBLE
        binding.confirm.visibility = View.INVISIBLE
        binding.textView3.visibility = View.INVISIBLE
        binding.textView4.visibility = View.INVISIBLE
        binding.seePass.visibility = View.INVISIBLE

        binding.sign.setOnClickListener {
            binding.userSig.visibility = View.VISIBLE
            binding.passSig.visibility = View.VISIBLE
            binding.confirm.visibility = View.VISIBLE
            binding.textView3.visibility = View.VISIBLE
            binding.textView4.visibility = View.VISIBLE
            binding.seePass.visibility = View.VISIBLE

            binding.seePass.setOnClickListener {
                togglePasswordVisibility()
            }


            binding.confirm.setOnClickListener {

            }
        }

        binding.register.setOnClickListener {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }
    }

    //metodo para la visibilidad de la contraseña
    private fun togglePasswordVisibility() {
        val isPasswordVisible = binding.passSig.transformationMethod == null

        // Cambia la visibilidad de la contraseña
        binding.passSig.transformationMethod = if (isPasswordVisible) {
            PasswordTransformationMethod.getInstance()
        } else {
            null
        }

        // Actualiza el icono según la visibilidad actual de la contraseña
        binding.seePass.setImageResource(
            if (isPasswordVisible) R.drawable.pass_invisible
            else R.drawable.eye
        )

        // Mueve el cursor al final del texto
        binding.passSig.setSelection(binding.passSig.text.length)
    }
}
