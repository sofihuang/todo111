package com.example.myapp

data class PhotoResponse(
    val results: List<User>,
    val info: Info
)

data class User(
    val picture: UserPicture,
    val login: UserLogin
)

data class UserPicture(
    val medium: String
)

data class UserLogin(
    val uuid: String
)

data class Info(
    val seed: String,
    val results: Int,
    val page: Int,
    val version: String
)

