package com.example.myapp

import android.app.Activity
import android.app.AlertDialog
import android.app.Instrumentation
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.Html
import android.text.TextWatcher
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat.startActivity
import androidx.core.content.FileProvider
import com.example.myapp.databinding.ActivityRegisterBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Register : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding

    // Lista para almacenar las URL de las imágenes
    private val imageUrls = mutableListOf<String>()

    // Conjunto para almacenar UUIDs únicos
    private val userId = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Establece la Toolbar como la ActionBar de la actividad
        val toolbar = binding.toolbar
        setSupportActionBar(toolbar)

        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        setupBottomNavigationView()
        ////////////////////////////////////////////////////////////////
        // ERROR quiero obligar usuario a rellenar gender para luego solo devuelve female o male ////////////
        val retrofit = Retrofit.Builder()
            .baseUrl("https://randomuser.me/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(PhotoService::class.java)

        //avatar
        binding.btnRandom.setOnClickListener {
            //pulsa random photo
            Log.d("sofia", "random avatar")
            //elimina url y id anteriores
            imageUrls.clear()
            userId.clear()

            //recuperar 3 avatar aleatorio
            if (binding.gender.text.toString() != null) {
                generateRandomAvatar(service)
            } else {
                Toast.makeText(this, "please fill your gender first", Toast.LENGTH_SHORT).show()
                Log.d("sofia", "en caso no haya rellenado gender")
            }
        }

        binding.takePhoto.setOnClickListener {
            startForResult.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        }

        //validar los datos basicos
        setupTextWatchers()

        binding.term.setOnClickListener {
            promptTerm()
        }


        //registracion con exito
        binding.confirmReg.setOnClickListener {
            if (setupTextWatchers() && binding.avatarReg != null && binding.term.isChecked) {

                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            // El usuario se registró correctamente en Firebase Authentication
                            val firebaseUser = FirebaseAuth.getInstance().currentUser

                            // Almacenar información adicional en Firebase Realtime Database
                            val databaseReference: DatabaseReference =
                                FirebaseDatabase.getInstance().getReference("users")

                            val userId = firebaseUser?.uid
                            userId?.let {
                                val user = User(
                                    uid = userId,
                                    userName = userName,
                                    password = password,
                                    birthday = birthday,
                                    gender = gender,
                                    avatar = avatar
                                )

                                // Utiliza el UID del usuario como clave para almacenar los datos en la base de datos
                                databaseReference.child(it).setValue(user)

                                // Muestra el mensaje y redirige a la actividad principal
                                Toast.makeText(this, "Usuario registrado correctamente", Toast.LENGTH_SHORT)
                                    .show()
                                val intent = Intent(this, FirstActivity::class.java)
                                startActivity(intent)
                            }
                        } else {
                            // Si el registro falla, muestra un mensaje de error
                            showAlert("Error en el registro: ${task.exception?.message}")
                        }
                    }
            } else {
                showAlert("Todos los campos deben estar completos y ser válidos, y debes aceptar los términos y condiciones")
            }
        }
                Toast.makeText(this, "you can SIGN IN to use this app", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, FirstActivity::class.java)
                startActivity(intent)
            } else {
                showAlert("All the field must be filled and valid , and you have to accept terms and conditions")
            }
        }


    }

    fun showAlert(message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("SofiApp")
        builder.setMessage(message)
        builder.setPositiveButton("Accept", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    //para terms y conditions
    private fun promptTerm() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Terms and Conditions")

        val scrollView = ScrollView(this)
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val textView = TextView(this)
        val terms = resources.getString(R.string.terms_conditions)
        val spannedText = Html.fromHtml(terms)
        textView.text = spannedText
        layout.addView(textView)

        scrollView.addView(layout)
        builder.setView(scrollView)

        builder.setPositiveButton("Accept") { dialogInterface, i ->

            dialogInterface.dismiss()
            binding.term.isChecked = true

        }

        builder.setNegativeButton("Cancel") { dialogInterface, i ->
            dialogInterface.dismiss()
            binding.term.isChecked = false
            Toast.makeText(this, "you must accept terms and conditions", Toast.LENGTH_SHORT).show()
        }

        val dialog = builder.create()
        dialog.show()
    }

    //funcion que recupera foto de camara
    private val startForResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == Activity.RESULT_OK) {
                Log.d("sofia", "result ok")
                val intent = result.data
                val imageBitmap = intent?.extras?.get("data") as Bitmap
                val imageView = binding.avatarReg
                imageView.setImageBitmap(imageBitmap)

            }
        }

    //sino haber rellenado campo gender devuelve foto -> random gender
    private fun generateRandomAvatar(service: PhotoService) {
        // Hacer la llamada tres veces
        repeat(3) {

            // En caso de que el usuario no haya completado el campo "gender"
            val gender = binding.gender?.text?.toString()

            val call: Call<PhotoResponse>? = when {
                gender.isNullOrEmpty() -> {
                    // Si el campo "gender" está vacío, no hacer ninguna llamada
                    null
                }

                gender == "female" || gender == "male" -> {
                    // Hacer la llamada al servicio correspondiente según el género especificado
                    service.getRandomPhoto(gender)
                }

                else -> {
                    // Si el género no es "female" ni "male", no hacer ninguna llamada
                    null
                }
            }

            call?.enqueue(object : Callback<PhotoResponse> {
                override fun onResponse(
                    call: Call<PhotoResponse>,
                    response: Response<PhotoResponse>
                ) {
                    if (response.isSuccessful) {
                        val photoResponse = response.body()
                        Log.d("sofia", photoResponse.toString())
                        if (photoResponse != null && photoResponse.results.isNotEmpty()) {
                            val user = photoResponse.results[0]
                            val uuid = user.login.uuid
                            val picture = user.picture
                            val medium = picture.medium
                            Log.d("sofia", "user: $user")
                            Log.d("sofia", "UUID: $uuid")
                            Log.d("sofia", "Picture: $picture")
                            Log.d("sofia", "URL Medium: $medium")
                            if (!userId.contains(uuid) && !medium.isNullOrEmpty()) {
                                Log.d("sofia", "Conseguir imagen , y uuid unica")
                                userId.add(uuid)
                                imageUrls.add(medium)
                                Log.d("sofia", "Image URLs: $imageUrls")
                                // Cuando tienes tres URL de imágenes de tamaño medio, puedes procesarlas
                                if (imageUrls.size == 3) {
                                    // Mostrar las imágenes con Picasso
                                    Picasso.get().load(imageUrls[0]).into(binding.random1)
                                    Picasso.get().load(imageUrls[1]).into(binding.random2)
                                    Picasso.get().load(imageUrls[2]).into(binding.random3)
                                }
                            }
                        }
                    }
                }

                override fun onFailure(call: Call<PhotoResponse>, t: Throwable) {
                    // Manejar error
                    Log.e("sofia", "Error fetching random photo", t)
                }
            })

            setAvatarReg()
        }
    }

    private fun setAvatarReg() {
        //si usuario elige uno de ellos , hay que asignarlo a avatar
        binding.random1.setOnClickListener {
            Picasso.get().load(imageUrls[0]).into(binding.avatarReg)
        }

        binding.random2.setOnClickListener {
            Picasso.get().load(imageUrls[1]).into(binding.avatarReg)
        }

        binding.random3.setOnClickListener {
            Picasso.get().load(imageUrls[2]).into(binding.avatarReg)
        }
    }

    //valida todos campos
    fun setupTextWatchers(): Boolean {
        var allValid = true

        allValid = allValid && setupFieldWatcher(
            binding.usernameReg,
            ::validateUsername,
            "Character's length 4-15 "
        )
        allValid = allValid && setupFieldWatcher(
            binding.passReg,
            ::validatePassword,
            "Password's length 6-15, must contain 1 number, 1 capital letter, 1 punctuation mark"
        )
        allValid = allValid && setupFieldWatcher(
            binding.pass2Reg,
            ::validatePassword2,
            "This field must be the same as Password"
        )
        allValid =
            allValid && setupFieldWatcher(binding.birthday, ::validateBirthday, "Date invalid")
        allValid =
            allValid && setupFieldWatcher(binding.gender, ::validateGender, "Only female / male")

        return allValid
    }

    //valida cada campo
    fun setupFieldWatcher(
        editText: EditText,
        isValid: (String) -> Boolean,
        errorMessage: String
    ): Boolean {
        var isValidInput = true

        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val userInput = s.toString().trim()
                isValidInput = userInput.isNotEmpty() && isValid(userInput)
                editText.error = if (!isValidInput) errorMessage else null
            }
        })

        return isValidInput
    }

    fun validateUsername(username: String): Boolean {
        //validar si entre 4 - 15 de caracteres alfanumerico
        val regexUser = "^[a-zA-Z0-9]{4,15}$".toRegex()
        return regexUser.matches(username)
    }

    fun validatePassword(password: String): Boolean {
        val passwordRegex = Regex("^(?=.*[0-9])(?=.*[A-Z])(?=.*[.,-_@#$%&]).{6,15}$")
        return passwordRegex.matches(password)
    }

    fun validatePassword2(password: String): Boolean {
        return samePass(binding.passReg.text.toString(), binding.pass2Reg.text.toString())
    }

    fun samePass(password: String, password2: String): Boolean {
        return password == password2
    }

    fun validateBirthday(birthday: String): Boolean {
        //esta expresion para que solo acepta formato dd/mm/yyyy
        val regexPattern = """^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\d{4}$""".toRegex()

        if (regexPattern.matches(birthday)) {
            try {
                val birthdayDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val birthdayDate = birthdayDateFormat.parse(birthday)
                val currentDate = Calendar.getInstance().time
                return birthdayDate != null && birthdayDate.before(currentDate)
            } catch (e: ParseException) {
                Log.e("sofia", "Error al parsear la cadena de fecha: ${e.message}")
            }
        }

        return false
    }


    fun validateGender(gender: String): Boolean {
        val validGenders = listOf("male", "female")
        return validGenders.contains(gender)
    }

    // Inflar el menú
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    //si elecciona share
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_share -> {

                // debe ser el enlace de la aplicación en la Play Store, sustituyo otro
                val urlToShare = "https://tu-url-aqui.com"
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(Intent.EXTRA_TEXT, urlToShare)
                sendIntent.type = "text/plain"
                startActivity(sendIntent)
                return true
            }

            else -> return super.onOptionsItemSelected(item)
        }
    }

    //nav menu
    private fun setupBottomNavigationView() {
        val bottomNavigationView = binding.menu1

        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.home -> {
                    // Navegar a MainActivity
                    val intent = Intent(this@Register, FirstActivity::class.java)
                    startActivity(intent)
                    true
                }

                R.id.history -> {
                    //en momento no hace nada
                    true
                }

                R.id.account -> {
                    //en momento no hace nada
                    true
                }

                else -> false
            }
        }
    }


}